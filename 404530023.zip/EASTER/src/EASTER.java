/**�إ�class EASTER,�إ�MAIN��k*/
public class EASTER {
public static void main(String[]args)/**�I�sEASTERTESTER�BcalculateEaster��k�A��J20012012*/
{
	EASTERTESTER ayear=new EASTERTESTER();
	System.out.println(ayear.calculateEaster(2001));
	System.out.println(ayear.calculateEaster(2012));
}
}
